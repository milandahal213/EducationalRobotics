Thank you for supporting Arduino and the OpenMV project!

To download the OpenMV IDE, please visit:
https://openmv.io/pages/download

For tutorials and documentation, please visit:
https://docs.arduino.cc/
http://docs.openmv.io/

For technical OpenMV support and projects, please visit the forums:
http://forums.openmv.io/

For Arduino related issues, please visit the Arduino help center:
https://support.arduino.cc/

Please use Github to report bugs and issues:
https://github.com/openmv/openmv

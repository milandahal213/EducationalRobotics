Edit the file secrets.py in Arduino Code folder with your SSID and PWD. Run the server.py in the Arduino Code folder. I would screen to grab the ip address of the server. 

Run the index.html on your browser. Enter the ip from Arduino. Hit start 

Use teachable machines to train 6 classes:
1. Start - Beginning of the code 
2. Stop - End of the code
3. Play - Playback the sequence
4. Ignore - background 
5. 0 - Move to 0 degrees
6. 90 - Move to 90 degrees
7. 180 - Move to 180 degrees
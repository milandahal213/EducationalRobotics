try:
  import usocket as socket
except:
  import socket

from machine import Pin
import network
import ujson
import secrets
import servoM

import gc
gc.collect()
motor=servoM.Servo(15)



try:
    ssid = secrets.SSID  
    password = secrets.PWD

except:
    print("secrets.py missing!! create a secrets.py and add SSID and PWD variables with correct credentials")

station = network.WLAN(network.STA_IF)

station.active(True)
station.connect(ssid, password)

while station.isconnected() == False:
  pass

print('Connection successful')
print(station.ifconfig())





def doSomething(req):
    try:
        a=ujson.loads(req)
        temp=0
        print(a)
        print(type(a))
        motor.move(a)
        return("moved")
    except:
        return("Error")





s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('',5050))
s.listen(5)

while True:
    try:
        if gc.mem_free() < 102000:
            gc.collect()
        conn, addr = s.accept()
        conn.settimeout(3.0)
        print('Received HTTP connection request from %s' % str(addr))
        request = conn.recv(1024) # receive the data
        conn.settimeout(None)
        body=request.split(b'\r\n')[-1] # parse the string to isolate the payload
        resp=doSomething(body)          # send the json string to do whatever you want
        conn.send('HTTP/1.1 200 OK\n')
        conn.send('Access-Control-Allow-Origin: *\n')
        conn.send('Access-Control-Allow-Credentials: true\n')
        conn.send('Application-Type: text/json\n')
        conn.send('Content-Type: text/html\n')
        conn.send('Connection: close\n\n')
        conn.send(resp)
        conn.close()

    except OSError as e:
        conn.close()
        print('Connection closed')
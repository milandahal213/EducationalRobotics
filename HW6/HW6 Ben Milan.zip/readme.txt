Edit the file secrets.py in Arduino Code folder with your SSID and PWD. Run the server.py in the Arduino Code folder. I would screen to grab the ip address of the server. 

Run the index.html on your browser. Enter the ip from Arduino. Hit start 
from RGB import *

while True:
    RED(1)
    time.sleep(0.5)
    BLUE(1)
    time.sleep(0.5)
    GREEN(1)
    time.sleep(0.5)
    RED(0)
    time.sleep(0.5)
    BLUE(0)
    time.sleep(0.5)
    GREEN(0)
    time.sleep(0.5)

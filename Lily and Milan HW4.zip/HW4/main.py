import servoM
from RGB import *

s1=servoM.Servo(15)
s2=servoM.Servo(17)
RED(1)
GREEN(0)
BLUE(0)